poi_id.py............. contains python code necessary to make final classifier and dataset alongwith features list
tester.py ............ contains the testing code provided by Udacity


poi_identifier.ipynb ............. IPython notebook which contains all the code and the required documentation/report
report.html .............. exported HTML version of the IPython notebook



List of github repos/resources used:

1. https://github.com/tybyers/Udacity_IntroMachineLearning
2. https://github.com/DariaAlekseeva/Enron_Dataset
3. Sklearn documenation for all the functions used.