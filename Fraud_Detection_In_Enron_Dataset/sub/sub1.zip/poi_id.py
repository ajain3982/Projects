#!/usr/bin/python

import sys
import pickle
sys.path.append("../tools/")

from feature_format import featureFormat, targetFeatureSplit
from tester import dump_classifier_and_data
import my_resources as mrs

### Task 1: Select what features you'll use.
### features_list is a list of strings, each of which is a feature name.
### The first feature must be "poi".
features_list = ['poi','salary'] # You will need to use more features

### Load the dictionary containing the dataset
with open("final_project_dataset.pkl", "r") as data_file:
    data_dict = pickle.load(data_file)

enron_data = mrs.load_data_in_pandas(data_dict)


### Task 2: Remove outliers
enron_data.drop('TOTAL',inplace=True)

print enron_data.shape
### Task 3: Create new feature(s)
enron_data = mrs.create_new_features(enron_data)


## Removing some features from the dataset
# cols_to_remove = ['director_fees', 'loan_advances', 'deferral_payments', 'restricted_stock_deferred','other']
# enron_data.drop(cols_to_remove,axis=1,inplace=True)



### Extract features and labels from dataset for local testing
target = enron_data['poi']
enron_data.drop('poi',axis=1,inplace=True)
enron_data.drop('email_address',axis=1,inplace=True)

## Scaling Features
enron_data = enron_data.apply(mrs.scaler)

### Store to my_dataset for easy export below.
enron_data['poi'] = target
d2 = enron_data.T
my_dataset = d2.to_dict()
enron_data.drop('poi',axis=1,inplace=True)


### Task 4: Try a varity of classifiers
# Tried different classifiers with testing hyperparameter tuning done via GridSearchCV. 
# Commented out the code which was used for testing. Final model used is Adaboost Classifier 
# with the feature list and parameters as below.
from sklearn.ensemble import AdaBoostClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn import tree
features_list = ['poi','bonus', 'deferred_income', 'long_term_incentive', 'restricted_stock', 'salary', 'total_stock_value', 'fraction_to_poi', 'bonus_salary_ratio']
clf = tree.DecisionTreeClassifier(min_samples_split = 2, max_depth = 14)

# from sklearn.svm import SVC
# svc = SVC(random_state=42)
# params = {'C': [1, 10, 50,100],
#           'gamma': [0.001,0.0001,0.002,0.005], 
#           'kernel': ['linear','rbf']}
# mrs.main(svc,params,enron_data,target)

# from sklearn import tree
# clf_tree = tree.DecisionTreeClassifier()
# params = {'min_samples_split':[2,5,10,15,20,50,70,100],
#          'max_depth':[2,5,7,10,14],
#          }
# mrs.main(clf_tree,params,enron_data,target)

# from sklearn.ensemble import RandomForestClassifier
# rfc_clf = RandomForestClassifier()
# params = {'n_estimators':[10,20,30,40,50,60,100],
#          'min_samples_split':[2,5,10,15,20,30,50],
#          }
# mrs.main(rfc_clf,params,enron_data,target)

# from sklearn.naive_bayes import GaussianNB
# nb_clf = GaussianNB()
# params = {}
# mrs.main(nb_clf,params,enron_data,target)

# from sklearn.ensemble import AdaBoostClassifier
# adb_clf = AdaBoostClassifier()
# params = {'n_estimators':[1,10,20,50,100,150,200,500],
#          'learning_rate':[1,0.9,0.8,0.5,0.3],
#          'algorithm':['SAMME.R']}
# mrs.main(adb_clf,params,enron_data,target)


# ### Task 5: Tune your classifier to achieve better than .3 precision and recall 
# ### using our testing script. Check the tester.py script in the final project
# ### folder for details on the evaluation method, especially the test_classifier
# ### function. Because of the small size of the dataset, the script uses
# ### stratified shuffle split cross validation. For more info: 
# ### http://scikit-learn.org/stable/modules/generated/sklearn.cross_validation.StratifiedShuffleSplit.html

# # Example starting point. Try investigating other evaluation techniques!
# from sklearn.cross_validation import train_test_split
# features_train, features_test, labels_train, labels_test = \
#     train_test_split(features, labels, test_size=0.3, random_state=42)

# ### Task 6: Dump your classifier, dataset, and features_list so anyone can
# ### check your results. You do not need to change anything below, but make sure
# ### that the version of poi_id.py that you submit can be run on its own and
# ### generates the necessary .pkl files for validating your results.

dump_classifier_and_data(clf, my_dataset, features_list)